utils::globalVariables(c("tnum.var.nspace", "tnum.var.ip", "tnum.var.nspaces", "tnum.var.token","tnum.var.result","tnum.var.postedJSON"))
